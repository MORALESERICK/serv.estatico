
App estática con datos fake (extraídos de Explicacion.md).

Cómo usar:
1. Descomprime el zip y entra a la carpeta:
   cd alumnos_app
2. Instala dependencias:
   npm install
3. Inicia el servidor:
   npm start
4. Abre en el navegador:
   http://localhost:3000

Contenido generado:
- public/ (index.html, data.js, app.js, styles.css)
- server.js (servidor express)
- package.json

Este paquete se generó a partir de los datos encontrados en `/mnt/data/Explicacion.md`.
