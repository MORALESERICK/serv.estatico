
function renderTable(data) {
  const tbody = document.querySelector("#tabla tbody");
  tbody.innerHTML = "";
  data.forEach(a=>{
    const tr = document.createElement("tr");
    const nombre = (a.first_name || "") + " " + (a.last_name || "");
    tr.innerHTML = `<td>${a.id}</td><td>${nombre}</td><td>${a.gender||""}</td><td>${a.estado||""}</td><td>${a.carrera||""}</td>`;
    tbody.appendChild(tr);
  });
  document.getElementById("count").textContent = data.length + " registros";
}

function setupFilters(data) {
  const select = document.getElementById("filtroCarrera");
  const carreras = Array.from(new Set(data.map(x=>x.carrera))).sort();
  carreras.forEach(c=>{
    const opt = document.createElement("option"); opt.value = c; opt.textContent = c; select.appendChild(opt);
  });

  document.getElementById("filtroCarrera").addEventListener("change", applyFilters);
  document.getElementById("busqueda").addEventListener("input", applyFilters);
  document.getElementById("reset").addEventListener("click", ()=>{
    document.getElementById("filtroCarrera").value = "";
    document.getElementById("busqueda").value = "";
    renderTable(window.alumnos);
  });

  function applyFilters(){
    const carr = document.getElementById("filtroCarrera").value.trim();
    const q = document.getElementById("busqueda").value.trim().toLowerCase();
    let res = window.alumnos.slice();
    if(carr) res = res.filter(r=>r.carrera === carr);
    if(q) res = res.filter(r=>((r.first_name||"")+ " " + (r.last_name||"")).toLowerCase().includes(q));
    renderTable(res);
  }
}

document.addEventListener("DOMContentLoaded", ()=>{
  if(!window.alumnos || !Array.isArray(window.alumnos)){
    document.body.innerHTML = "<p>Error: no se encontró la variable <code>alumnos</code> en data.js</p>";
    return;
  }
  renderTable(window.alumnos);
  setupFilters(window.alumnos);
});
